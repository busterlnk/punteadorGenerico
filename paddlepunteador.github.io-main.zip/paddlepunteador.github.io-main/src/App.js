import React from 'react'
import Contador from './Contador'

function App() {
  return (
    <div>
      <Contador />
    </div>
  );
}

export default App;
