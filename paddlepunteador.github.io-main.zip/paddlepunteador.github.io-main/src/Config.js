// import firebase from 'firebase/app';
// import 'firebase/database'


// var Config = {
//     apiKey: "AIzaSyBgwpoqanque0kR0_S-S6qumKPeEB_wS1w",
//     authDomain: "punteador-9cd23.firebaseapp.com",
//     databaseURL: "https://punteador-9cd23-default-rtdb.firebaseio.com",
//     projectId: "punteador-9cd23",
//     storageBucket: "punteador-9cd23.appspot.com",
//     messagingSenderId: "73532947608",
//     appId: "1:73532947608:web:a14c4007b337aa5c3b64ed"
//   };

//   firebase.initializeApp(Config)

//   const db = firebase.database()
//   export default db;


// // export const fire = {
// //     apiKey: "AIzaSyBgwpoqanque0kR0_S-S6qumKPeEB_wS1w",
// //     authDomain: "punteador-9cd23.firebaseapp.com",
// //     databaseURL: "https://punteador-9cd23-default-rtdb.firebaseio.com",
// //     projectId: "punteador-9cd23",
// //     storageBucket: "punteador-9cd23.appspot.com",
// //     messagingSenderId: "73532947608",
// //     appId: "1:73532947608:web:a14c4007b337aa5c3b64ed"
// // };